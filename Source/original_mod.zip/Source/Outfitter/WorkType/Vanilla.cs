﻿namespace Outfitter.WorkType
{
    public static class Vanilla
    {
        public const string Doctor       = "Doctor";
        public const string Warden       = "Warden";
        public const string Handling     = "Handling";
        public const string Cooking      = "Cooking";
        public const string Hunting      = "Hunting";
        public const string Construction = "Construction";
        public const string Growing      = "Growing";
        public const string Mining       = "Mining";
        public const string PlantCutting = "PlantCutting";
        public const string Smithing     = "Smithing";
        public const string Tailoring    = "Tailoring";
        public const string Art          = "Art";
        public const string Crafting     = "Crafting";
        public const string Hauling      = "Hauling";
        public const string Cleaning     = "Cleaning";
        public const string Research     = "Research";
    }
}