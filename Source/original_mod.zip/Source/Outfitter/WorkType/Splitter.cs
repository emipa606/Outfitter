﻿namespace Outfitter.WorkType
{
    public static class Splitter
    {
        public const string Butcher      = "Butchering";
        public const string Repair       = "Repairing";
        public const string Drugs        = "Drugs";
        public const string Brewing      = "Brewing";
        public const string Drilling     = "Drilling";
        public const string Taming       = "Taming";
        public const string Training     = "Training";
        public const string Refining     = "Refining";
        public const string Surgeon      = "Surgeon";
        public const string Harvesting   = "Harvesting";
        public const string Components   = "Assembling";
        public const string Stonecutting = "Stonecutting";
        public const string Smelting     = "Smelting";
    }
}