﻿namespace Outfitter.WorkType
{
    public static class FSF
    {
        public const string Butcher = "FSFButcher";

        public const string Brewing = "FSFBrewing";

        public const string Repair = "FSFRepair";

        public const string Training = "FSFTraining";

        public const string Drilling = "FSFDrilling";

        public const string Drugs = "FSFDrugs";

        public const string Components = "FSFComponents";

        public const string Refining = "FSFRefining";

        public const string Surgeon = "FSFSurgeon";
    }
}
