﻿namespace Outfitter.WorkType
{
    public static class Other
    {
        public const string FluffyManaging = "Managing";

        public const string HospitalityDiplomat = "Diplomat";
    }
}
