namespace Outfitter.Enums
{
    public enum StatAssignment
    {
        Manual,

        Override,

        Individual,

        Automatic
    }
}