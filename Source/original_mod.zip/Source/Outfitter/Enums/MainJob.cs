﻿namespace Outfitter.Enums
{
    public enum MainJob
    {
        Anything,

        Soldier00CloseCombat,

        Soldier00RangedCombat,

        Artist,

        Constructor,

        Cook,

        Crafter,

        Doctor,

        Grower,

        Handler,

        Hauler,

        Hunter,

        Miner,

        Researcher,

        Smith,

        Tailor,

        Warden
    }
}